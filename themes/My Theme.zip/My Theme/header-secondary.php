<!DOCTYPE html>
<html lang="en">
<head>

	<meta charset="UTF-8">
	<title></title>


	<?php wp_head();?>



</head>
<body>

THIS IS THE SECOND HEADER